import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  discordId: text("discord_id").notNull().unique(),
  username: text("username").notNull(),
  role: text("role").default("customer"), // customer, chef, admin
  points: integer("points").default(0),
  ordersCompleted: integer("orders_completed").default(0),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderId: text("order_id").notNull().unique(), // The friendly ID (e.g. #123)
  customerId: text("customer_id"), // Discord ID of customer
  chefId: text("chef_id"), // Discord ID of chef
  status: text("status").default("pending"), // pending, claimed, completed
  details: text("details"),
  channelId: text("channel_id"), // Private ticket channel ID
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertOrderSchema = createInsertSchema(orders).omit({ id: true, createdAt: true });

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
