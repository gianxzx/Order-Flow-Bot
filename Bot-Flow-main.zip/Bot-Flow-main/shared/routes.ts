import { z } from 'zod';
import { users, orders } from './schema';

export const api = {
  stats: {
    get: {
      method: 'GET' as const,
      path: '/api/stats',
      responses: {
        200: z.object({
          totalOrders: z.number(),
          totalPoints: z.number(),
          topChefs: z.array(z.object({
            username: z.string(),
            points: z.number(),
            ordersCompleted: z.number(),
          })),
          topCustomers: z.array(z.object({
            username: z.string(),
            points: z.number(),
            ordersCompleted: z.number(),
          })),
        }),
      },
    },
  },
};
