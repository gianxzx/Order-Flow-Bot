import { useStats } from "@/hooks/use-stats";
import { StatsCard } from "@/components/StatsCard";
import { LeaderboardTable } from "@/components/LeaderboardTable";
import { 
  UtensilsCrossed, 
  Trophy, 
  Activity, 
  Server,
  ChefHat,
  Users
} from "lucide-react";

export default function Home() {
  const { data: stats, isLoading, isError } = useStats();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center text-center p-4">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mb-6" />
        <h2 className="text-2xl font-display font-bold text-foreground">Loading Dashboard...</h2>
        <p className="text-muted-foreground mt-2">Connecting to Discord Bot Service</p>
      </div>
    );
  }

  if (isError || !stats) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center text-center p-4">
        <div className="p-6 bg-destructive/10 rounded-full mb-6 text-destructive">
          <Server className="w-12 h-12" />
        </div>
        <h2 className="text-2xl font-display font-bold text-foreground">System Offline</h2>
        <p className="text-muted-foreground mt-2 max-w-md">
          Unable to fetch stats. The bot might be restarting or undergoing maintenance.
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary/30">
      {/* Header / Hero Section */}
      <header className="relative overflow-hidden border-b border-white/5 bg-card/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="bg-primary p-3 rounded-xl shadow-lg shadow-primary/25">
                <UtensilsCrossed className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold font-display tracking-tight">Order Bot Dashboard</h1>
                <p className="text-sm text-muted-foreground flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  System Operational
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="px-4 py-2 rounded-lg bg-secondary/50 border border-white/5 text-xs font-mono text-muted-foreground">
                v1.0.0
              </div>
              <a 
                href="https://discord.com" 
                target="_blank" 
                rel="noreferrer"
                className="px-6 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-sm font-medium transition-colors border border-white/5"
              >
                Join Discord
              </a>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <StatsCard 
            title="Total Orders" 
            value={stats.totalOrders} 
            icon={ChefHat}
            description="Lifetime completed orders"
            delay={100}
            className="border-blue-500/20 hover:border-blue-500/40"
          />
          <StatsCard 
            title="Total Points" 
            value={stats.totalPoints} 
            icon={Trophy}
            description="Awarded to community"
            delay={200}
            className="border-yellow-500/20 hover:border-yellow-500/40"
          />
          <StatsCard 
            title="Active Chefs" 
            value={stats.topChefs.length} 
            icon={Users}
            description="Top performers"
            delay={300}
            className="border-purple-500/20 hover:border-purple-500/40"
          />
          <StatsCard 
            title="System Status" 
            value="Online" 
            icon={Activity}
            description="Latency: 24ms"
            delay={400}
            className="border-green-500/20 hover:border-green-500/40"
          />
        </div>

        {/* Leaderboards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <LeaderboardTable 
            title="Top Chefs" 
            data={stats.topChefs} 
            type="chef"
            delay={500}
          />
          <LeaderboardTable 
            title="Top Customers" 
            data={stats.topCustomers} 
            type="customer"
            delay={600}
          />
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 bg-black/20 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <p>© 2024 Discord Order Bot. All rights reserved.</p>
            <div className="flex items-center gap-6">
              <a href="#" className="hover:text-primary transition-colors">Documentation</a>
              <a href="#" className="hover:text-primary transition-colors">Support</a>
              <a href="#" className="hover:text-primary transition-colors">Terms</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
