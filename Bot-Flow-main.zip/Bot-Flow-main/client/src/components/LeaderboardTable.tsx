import { User } from "lucide-react";

interface LeaderboardEntry {
  username: string;
  points: number;
  ordersCompleted: number;
}

interface LeaderboardTableProps {
  title: string;
  data: LeaderboardEntry[];
  type: "chef" | "customer";
  delay?: number;
}

export function LeaderboardTable({ title, data, type, delay = 0 }: LeaderboardTableProps) {
  return (
    <div 
      className="bg-card rounded-2xl border border-white/5 overflow-hidden flex flex-col shadow-lg animate-in fade-in slide-in-from-bottom-8 fill-mode-backwards"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="p-6 border-b border-white/5 bg-gradient-to-r from-card to-white/5">
        <h3 className="text-xl font-bold font-display flex items-center gap-2">
          {type === "chef" ? "👨‍🍳" : "🍽️"} {title}
        </h3>
      </div>
      
      <div className="flex-1 overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-white/5 bg-black/20 text-xs uppercase tracking-wider text-muted-foreground font-medium">
              <th className="p-4 pl-6 w-16 text-center">Rank</th>
              <th className="p-4">User</th>
              <th className="p-4 text-right">Orders</th>
              <th className="p-4 pr-6 text-right">Points</th>
            </tr>
          </thead>
          <tbody>
            {data.length === 0 ? (
              <tr>
                <td colSpan={4} className="p-8 text-center text-muted-foreground italic">
                  No data yet. Let's get cooking!
                </td>
              </tr>
            ) : (
              data.map((entry, index) => (
                <tr 
                  key={index}
                  className="group border-b border-white/5 last:border-0 hover:bg-white/5 transition-colors duration-200"
                >
                  <td className="p-4 pl-6 text-center">
                    <span className={`
                      inline-flex items-center justify-center w-8 h-8 rounded-full font-bold text-sm
                      ${index === 0 ? "bg-yellow-500/20 text-yellow-500 ring-1 ring-yellow-500/50" : ""}
                      ${index === 1 ? "bg-slate-400/20 text-slate-400 ring-1 ring-slate-400/50" : ""}
                      ${index === 2 ? "bg-amber-700/20 text-amber-700 ring-1 ring-amber-700/50" : ""}
                      ${index > 2 ? "text-muted-foreground" : ""}
                    `}>
                      {index + 1}
                    </span>
                  </td>
                  <td className="p-4 font-medium text-foreground flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-muted-foreground">
                      <User className="w-4 h-4" />
                    </div>
                    {entry.username}
                  </td>
                  <td className="p-4 text-right text-muted-foreground font-mono">
                    {entry.ordersCompleted}
                  </td>
                  <td className="p-4 pr-6 text-right font-bold text-primary font-mono group-hover:scale-110 transition-transform origin-right duration-200">
                    {entry.points}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
