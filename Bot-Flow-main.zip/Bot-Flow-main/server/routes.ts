import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { startBot } from "./bot";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Start Discord Bot
  startBot();

  // API Routes
  app.get(api.stats.get.path, async (req, res) => {
    const { totalOrders, totalPoints } = await storage.getStats();
    const topChefs = await storage.getTopChefs();
    const topCustomers = await storage.getTopCustomers();
    
    res.json({
      totalOrders,
      totalPoints,
      topChefs: topChefs.map(u => ({ username: u.username, points: u.points || 0, ordersCompleted: u.ordersCompleted || 0 })),
      topCustomers: topCustomers.map(u => ({ username: u.username, points: u.points || 0, ordersCompleted: u.ordersCompleted || 0 })),
    });
  });

  return httpServer;
}
