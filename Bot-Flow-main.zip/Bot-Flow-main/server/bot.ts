import { 
  Client, 
  Intents,
  MessageEmbed, 
  MessageActionRow, 
  MessageButton, 
  Permissions,
  TextChannel,
  type Interaction,
  type Message,
  type GuildMember
} from "discord.js";
import { REST } from "@discordjs/rest";
import { Routes } from "discord-api-types/v9";
import { SlashCommandBuilder } from "@discordjs/builders";
import { storage } from "./storage";

// --- Configuration ---
const DISCORD_TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;
const GUILD_ID = process.env.GUILD_ID;
const WEBHOOK_ID = process.env.WEBHOOK_ID;
const CHEF_ROLE_ID = process.env.CHEF_ROLE_ID?.replace(/[<@&>]/g, "") || "";
const ADMIN_ROLE_ID = process.env.ADMIN_ROLE_ID?.replace(/[<@&>]/g, "") || "";
const ORDER_CATEGORY_ID = process.env.ORDER_CATEGORY_ID;
const DISCOUNT_CHANNEL_ID = process.env.DISCOUNT_CHANNEL_ID;

if (!DISCORD_TOKEN) {
  console.warn("DISCORD_TOKEN is missing! Bot will not start.");
}

// Track processed messages to prevent duplicates
const processedMessages = new Set<string>();

export const client = new Client({
  intents: [
    Intents.FLAGS.GUILDS,
    Intents.FLAGS.GUILD_MESSAGES,
    Intents.FLAGS.GUILD_MEMBERS,
  ],
});

// --- Slash Commands Definitions (only 5 commands) ---
const commands = [
  new SlashCommandBuilder()
    .setName("customer-stats")
    .setDescription("Shows customer order stats")
    .addUserOption(option => option.setName("user").setDescription("The user to check").setRequired(false)),
  
  new SlashCommandBuilder()
    .setName("chef-stats")
    .setDescription("Shows chef order stats")
    .addUserOption(option => option.setName("user").setDescription("The chef to check").setRequired(false)),
    
  new SlashCommandBuilder()
    .setName("adjust-points")
    .setDescription("Adjust points for a user (Admin only)")
    .addUserOption(option => option.setName("user").setDescription("The user").setRequired(true))
    .addIntegerOption(option => option.setName("points").setDescription("Points to set").setRequired(true))
    .addStringOption(option => option.setName("reason").setDescription("Reason for adjustment")),

  new SlashCommandBuilder()
    .setName("lbreset")
    .setDescription("Reset leaderboards (Admin only)"),
    
  new SlashCommandBuilder()
    .setName("discount")
    .setDescription("Apply a discount to an order (Chefs only)")
    .addStringOption(option => option.setName("order_id").setDescription("Order ID (e.g., #1234)").setRequired(true))
    .addStringOption(option => option.setName("discount").setDescription("Discount (e.g., 25% or 25)").setRequired(true))
    .addUserOption(option => option.setName("customer").setDescription("Customer to ping").setRequired(true))
    .addStringOption(option => option.setName("description").setDescription("Discount description text").setRequired(true)),
];

// --- Bot Logic ---

export async function startBot() {
  if (!DISCORD_TOKEN) return;

  try {
    const rest = new REST({ version: "9" }).setToken(DISCORD_TOKEN);
    console.log("Started refreshing application (/) commands.");

    // Clean sync: First clear all existing commands, then register fresh
    if (CLIENT_ID) {
      // Clear global commands
      console.log("Clearing global commands...");
      await rest.put(Routes.applicationCommands(CLIENT_ID), { body: [] });
      
      // Clear guild commands if GUILD_ID is set
      if (GUILD_ID) {
        console.log("Clearing guild commands...");
        await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: [] });
        
        // Register commands to guild (faster updates during development)
        console.log("Registering 5 guild commands...");
        await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { 
          body: commands.map(cmd => cmd.toJSON()) 
        });
      } else {
        // Register global commands
        console.log("Registering 5 global commands...");
        await rest.put(Routes.applicationCommands(CLIENT_ID), { 
          body: commands.map(cmd => cmd.toJSON()) 
        });
      }
    }
    
    console.log("Successfully reloaded application (/) commands.");
    await client.login(DISCORD_TOKEN);
  } catch (error) {
    console.error("Error starting bot:", error);
  }
}

client.once("ready", () => {
  console.log(`Logged in as ${client.user?.tag}!`);
});

// --- Webhook / Order Intake ---
client.on("messageCreate", async (message) => {
  // Check for !close command in any channel (for ticket channels)
  if (message.content.toLowerCase().startsWith("!close")) {
    await handleCloseCommand(message);
    return;
  }

  // Check for !claim command 
  if (message.content.toLowerCase().startsWith("!claim")) {
    await handleClaimCommand(message);
    return;
  }
  
  // Only process messages in the webhook channel
  if (message.channelId !== WEBHOOK_ID) {
    return;
  }
  
  // Ignore messages from our own bot
  if (message.author.id === client.user?.id) {
    return;
  }

  // Prevent duplicate processing
  if (processedMessages.has(message.id)) {
    return;
  }
  processedMessages.add(message.id);
  
  // Clean up old processed messages (keep last 100)
  if (processedMessages.size > 100) {
    const arr = Array.from(processedMessages);
    for (let i = 0; i < arr.length - 100; i++) {
      processedMessages.delete(arr[i]);
    }
  }
  
  // Process messages from webhooks OR other bots in the webhook channel
  if (message.webhookId || message.author.bot) {
    console.log(`[Bot] Detected order in webhook channel from: ${message.author.username}`);
    await handleNewWebhookOrder(message);
  }
});

interface ParsedOrderData {
  discordUser: string | null;
  robloxUser: string | null;
  totalBill: number | null;
  discountPercent: number | null;
  rawContent: string;
}

function parseWebhookContent(message: Message): ParsedOrderData {
  let content = message.content || "";
  let discordUser: string | null = null;
  let robloxUser: string | null = null;
  let totalBill: number | null = null;
  let discountPercent: number | null = null;
  
  // If there's an embed, extract info from it
  if (message.embeds.length > 0) {
    const embed = message.embeds[0];
    const parts: string[] = [];
    
    if (embed.title) parts.push(`**${embed.title}**`);
    if (embed.description) parts.push(embed.description);
    
    // Extract field data
    if (embed.fields) {
      for (const field of embed.fields) {
        const fieldName = field.name.toLowerCase();
        const fieldValue = field.value;
        
        parts.push(`**${field.name}:** ${fieldValue}`);
        
        // Parse Discord User (strip markdown formatting)
        if (fieldName.includes('discord') && fieldName.includes('user')) {
          discordUser = fieldValue.replace(/\*\*/g, '').replace(/\*/g, '').replace(/__/g, '').replace(/_/g, '').trim();
        }
        
        // Parse Roblox User (strip markdown formatting)
        if (fieldName.includes('roblox') && fieldName.includes('user')) {
          robloxUser = fieldValue.replace(/\*\*/g, '').replace(/\*/g, '').replace(/__/g, '').replace(/_/g, '').trim();
        }
        
        // Parse Total Bill
        if (fieldName.includes('total') || fieldName.includes('bill') || fieldName.includes('price')) {
          const match = fieldValue.match(/[\d,.]+/);
          if (match) {
            totalBill = parseFloat(match[0].replace(/,/g, ''));
          }
        }
        
        // Parse Discount %
        if (fieldName.includes('discount')) {
          const match = fieldValue.match(/(\d+(?:\.\d+)?)\s*%?/);
          if (match) {
            discountPercent = parseFloat(match[1]);
          }
        }
      }
    }
    
    content = parts.join("\n") || content || "No content provided";
  }
  
  // Also try to parse from raw content if fields weren't found
  if (!discordUser) {
    const discordMatch = content.match(/discord\s*(?:user)?[:\s]+([^\n]+)/i);
    if (discordMatch) discordUser = discordMatch[1].replace(/\*\*/g, '').replace(/\*/g, '').trim();
  }
  
  if (!robloxUser) {
    const robloxMatch = content.match(/roblox\s*(?:user)?[:\s]+([^\n]+)/i);
    if (robloxMatch) robloxUser = robloxMatch[1].replace(/\*\*/g, '').replace(/\*/g, '').trim();
  }
  
  if (totalBill === null) {
    const totalMatch = content.match(/(?:total|bill|price)[:\s]*\$?([\d,.]+)/i);
    if (totalMatch) totalBill = parseFloat(totalMatch[1].replace(/,/g, ''));
  }
  
  if (discountPercent === null) {
    const discountMatch = content.match(/discount[:\s]*(\d+(?:\.\d+)?)\s*%?/i);
    if (discountMatch) discountPercent = parseFloat(discountMatch[1]);
  }
  
  return {
    discordUser,
    robloxUser,
    totalBill,
    discountPercent,
    rawContent: content
  };
}

async function findMemberByName(guild: any, username: string): Promise<GuildMember | null> {
  if (!username) return null;
  
  // Clean the username (remove @ and # but keep digits - usernames have numbers!)
  const cleanName = username.replace(/[@#]/g, '').trim().toLowerCase();
  
  console.log(`[Bot] Searching for member with cleaned name: "${cleanName}"`);
  
  try {
    // Fetch all members
    const members = await guild.members.fetch();
    
    // Try exact match first
    let found = members.find((m: GuildMember) => 
      m.user.username.toLowerCase() === cleanName ||
      m.displayName.toLowerCase() === cleanName ||
      m.user.tag.toLowerCase() === username.toLowerCase()
    );
    
    if (found) return found;
    
    // Try partial match
    found = members.find((m: GuildMember) => 
      m.user.username.toLowerCase().includes(cleanName) ||
      m.displayName.toLowerCase().includes(cleanName)
    );
    
    return found || null;
  } catch (error) {
    console.error("Error finding member:", error);
    return null;
  }
}

async function handleNewWebhookOrder(message: Message) {
  try {
    // Generate Order ID
    const orderRef = Math.floor(1000 + Math.random() * 9000).toString();
    const orderId = `#${orderRef}`;
    
    // Parse content from the message
    const parsed = parseWebhookContent(message);
    
    console.log(`[Bot] Processing order ${orderId}`);
    console.log(`[Bot] Parsed data - Discord User: ${parsed.discordUser}, Total: ${parsed.totalBill}, Discount: ${parsed.discountPercent}%`);
    
    // Find customer in guild
    const guild = message.guild;
    let customer: GuildMember | null = null;
    let customerId: string | null = null;
    
    if (guild && parsed.discordUser) {
      customer = await findMemberByName(guild, parsed.discordUser);
      if (customer) {
        customerId = customer.id;
        console.log(`[Bot] Found customer: ${customer.user.tag}`);
      } else {
        console.log(`[Bot] Could not find member: ${parsed.discordUser}`);
      }
    }
    
    // Calculate discount and new total
    let originalTotal = parsed.totalBill || 0;
    let discountAmount = 0;
    let newTotal = originalTotal;
    
    if (parsed.discountPercent && parsed.discountPercent > 0 && originalTotal > 0) {
      discountAmount = originalTotal * (parsed.discountPercent / 100);
      newTotal = originalTotal - discountAmount;
    }
    
    // Build receipt-style description
    let description = "";
    
    // Add discount info in the exact format from screenshot
    if (parsed.discountPercent && parsed.discountPercent > 0 && originalTotal > 0) {
      description += `Applied ${parsed.discountPercent}% discount to Order ${orderId}.\n`;
      description += `Original: **$${originalTotal.toFixed(0)}**\n`;
      description += `New total: **$${newTotal.toFixed(0)}**\n\n`;
    }
    
    if (parsed.robloxUser) {
      description += `**Roblox User:** ${parsed.robloxUser}\n`;
    }
    if (parsed.discordUser) {
      description += `**Discord User:** ${parsed.discordUser}`;
      if (customer) {
        description += ` (${customer})`;
      }
      description += "\n";
    }
    
    description += "\n**Order Details:**\n";
    description += parsed.rawContent.replace(/\*\*Discord User:\*\*.*\n?/gi, '')
                                    .replace(/\*\*Roblox User:\*\*.*\n?/gi, '')
                                    .replace(/\*\*Total.*\n?/gi, '')
                                    .replace(/\*\*Discount.*\n?/gi, '')
                                    .trim();
    
    // Create DB Record
    await storage.createOrder({
      orderId,
      status: "pending",
      details: parsed.rawContent,
      customerId: customerId,
    });

    // Create Receipt-style Embed
    const embed = new MessageEmbed()
      .setTitle(`New Order ${orderId}`)
      .setDescription(description)
      .setColor(0x00FF00)
      .setTimestamp();
    
    embed.addField("Status", "Pending Claim", true);
    embed.addField("Order ID (for /discount)", `\`${orderId}\``, true);

    // Buttons
    const row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId(`claim_${orderRef}`)
          .setLabel("Claim")
          .setStyle("SUCCESS"),
        new MessageButton()
          .setCustomId(`decline_${orderRef}`)
          .setLabel("Decline")
          .setStyle("DANGER")
      );

    // Send new embed with customer ping
    if (message.channel instanceof TextChannel) {
      let mentionContent = CHEF_ROLE_ID ? `<@&${CHEF_ROLE_ID}>` : "@here New Order!";
      if (customer) {
        mentionContent += ` | Customer: ${customer}`;
      }
      
      await message.channel.send({ 
        content: mentionContent,
        embeds: [embed], 
        components: [row] 
      });
      
      // Delete original webhook message to keep channel clean
      try {
        await message.delete();
        console.log(`[Bot] Deleted original webhook message`);
      } catch (err) {
        console.log(`[Bot] Could not delete webhook message:`, err);
      }
    }
    
  } catch (error) {
    console.error("Error handling webhook:", error);
  }
}

// --- Interaction Handling ---
client.on("interactionCreate", async (interaction: Interaction) => {
  try {
    if (interaction.isButton()) {
      await handleButton(interaction);
    } else if (interaction.isCommand()) {
      await handleSlashCommand(interaction);
    }
  } catch (error) {
    console.error("Interaction error:", error);
  }
});

async function handleButton(interaction: any) {
  const [action, orderRef] = interaction.customId.split("_");
  const orderId = `#${orderRef}`;

  if (action === "claim") {
    await handleClaim(interaction, orderId);
  } else if (action === "decline") {
    try {
      await interaction.message.delete();
      await interaction.reply({ content: "Order declined and removed.", ephemeral: true });
    } catch (err) {
      console.error("Error deleting message:", err);
      await interaction.reply({ content: "Could not delete the order.", ephemeral: true });
    }
  }
}

async function handleClaim(interaction: any, orderId: string) {
  const user = interaction.user;
  
  // Update DB
  const order = await storage.getOrder(orderId);
  if (!order || order.status !== 'pending') {
    return interaction.reply({ content: "Order already claimed or invalid.", ephemeral: true });
  }
  
  // Create Private Channel
  const guild = interaction.guild;
  if (!guild) return;
  
  const channelName = `order-${orderId.replace('#', '')}`;
  const parent = ORDER_CATEGORY_ID;
  
  // Build permission overwrites
  const permissionOverwrites: any[] = [
    {
      id: guild.id,
      deny: [Permissions.FLAGS.VIEW_CHANNEL],
    },
    {
      id: user.id,
      allow: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES],
    },
  ];
  
  // Add customer to channel if we have their ID
  if (order.customerId) {
    permissionOverwrites.push({
      id: order.customerId,
      allow: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES],
    });
  }
  
  const ticketChannel = await guild.channels.create(channelName, {
    type: "GUILD_TEXT",
    parent: parent,
    permissionOverwrites,
  });

  await storage.updateOrderStatus(orderId, "claimed", user.id, ticketChannel.id);
  
  // Register/Update Chef in DB
  let chef = await storage.getUserByDiscordId(user.id);
  if (!chef) {
    await storage.createUser({ discordId: user.id, username: user.username, role: "chef" });
  }

  // Post details in ticket
  const embed = new MessageEmbed()
    .setTitle(`Order ${orderId} Claimed`)
    .setDescription(`**Claimed by:** ${user}\n\n**Order Details:**\n${order.details}`)
    .setColor(0xFFFF00)
    .addField("Order ID", `\`${orderId}\``, true)
    .addField("Status", "In Progress", true)
    .setFooter({ text: "Use !close when the order is complete" });

  const customerMention = order.customerId ? `<@${order.customerId}>` : "(Customer not found in server)";
  
  await ticketChannel.send({ 
    content: `Order claimed by ${user}!\n\nCustomer: ${customerMention}`, 
    embeds: [embed] 
  });
  
  // Update the original embed to show who claimed it
  const claimedEmbed = new MessageEmbed(interaction.message.embeds[0])
    .setColor(0xFFFF00)
    .spliceFields(-2, 2)
    .addField("Status", `Claimed by ${user}`, true)
    .addField("Ticket", `${ticketChannel}`, true);
  
  // Remove buttons from original message and update embed
  await interaction.message.edit({ 
    embeds: [claimedEmbed], 
    components: [] 
  });
  
  await interaction.reply({ content: `Claimed! Ticket created: ${ticketChannel}`, ephemeral: true });
}

async function handleClaimCommand(message: Message) {
  const args = message.content.split(/\s+/);
  if (args.length < 2) {
    return message.reply("Usage: `!claim #1234` or `!claim 1234`");
  }
  
  let orderRef = args[1].replace('#', '');
  const orderId = `#${orderRef}`;
  
  const order = await storage.getOrder(orderId);
  if (!order) {
    return message.reply(`Order ${orderId} not found.`);
  }
  
  if (order.status !== 'pending') {
    return message.reply(`Order ${orderId} is already ${order.status}.`);
  }
  
  const guild = message.guild;
  const member = message.member;
  if (!guild || !member) return;
  
  const channelName = `order-${orderRef}`;
  const parent = ORDER_CATEGORY_ID;
  
  // Build permission overwrites
  const permissionOverwrites: any[] = [
    {
      id: guild.id,
      deny: [Permissions.FLAGS.VIEW_CHANNEL],
    },
    {
      id: member.id,
      allow: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES],
    },
  ];
  
  if (order.customerId) {
    permissionOverwrites.push({
      id: order.customerId,
      allow: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES],
    });
  }
  
  const ticketChannel = await guild.channels.create(channelName, {
    type: "GUILD_TEXT",
    parent: parent,
    permissionOverwrites,
  });

  await storage.updateOrderStatus(orderId, "claimed", member.id, ticketChannel.id);
  
  // Register/Update Chef in DB
  let chef = await storage.getUserByDiscordId(member.id);
  if (!chef) {
    await storage.createUser({ discordId: member.id, username: member.user.username, role: "chef" });
  }

  const embed = new MessageEmbed()
    .setTitle(`Order ${orderId} Claimed`)
    .setDescription(`**Claimed by:** ${member}\n\n**Order Details:**\n${order.details}`)
    .setColor(0xFFFF00)
    .addField("Order ID", `\`${orderId}\``, true)
    .addField("Status", "In Progress", true)
    .setFooter({ text: "Use !close when the order is complete" });

  const customerMention = order.customerId ? `<@${order.customerId}>` : "(Customer not found in server)";
  
  await ticketChannel.send({ 
    content: `Order claimed by ${member}!\n\nCustomer: ${customerMention}`, 
    embeds: [embed] 
  });
  
  await message.reply(`Order ${orderId} claimed! Ticket: ${ticketChannel}`);
}

async function handleCloseCommand(message: Message) {
  // Check if it's a ticket channel
  const order = await storage.getOrderByChannelId(message.channelId);
  if (!order || order.status !== 'claimed') return;
  
  const member = message.member;
  if (!member) return;
  
  const isChef = order.chefId === member.id;
  const isAdmin = member.roles.cache.has(ADMIN_ROLE_ID);
  
  if (!isChef && !isAdmin) {
    return message.reply("Only the claiming chef or admin can close this order.");
  }
  
  // Complete Order
  await storage.updateOrderStatus(order.orderId, "completed");
  
  // Award Points
  if (order.chefId) {
    await storage.updateUserPoints(order.chefId, 1);
    await storage.incrementUserOrders(order.chefId);
  }
  if (order.customerId) {
    await storage.updateUserPoints(order.customerId, 1);
    await storage.incrementUserOrders(order.customerId);
  }
  
  // Final Embed
  const embed = new MessageEmbed()
    .setTitle("Order Completed")
    .setDescription(`Order ${order.orderId} is now closed.\n\n**Points Awarded:**\nChef: +1\nCustomer: +1`)
    .setColor(0x0000FF);
    
  await message.channel.send({ embeds: [embed] });
  
  // Delete channel after delay
  setTimeout(() => {
    if (message.channel instanceof TextChannel) {
      message.channel.delete().catch(console.error);
    }
  }, 5000);
}

async function handleSlashCommand(interaction: any) {
  const { commandName, options } = interaction;
  
  if (commandName === 'customer-stats' || commandName === 'chef-stats') {
    const target = options.getUser('user') || interaction.user;
    const user = await storage.getUserByDiscordId(target.id);
    
    const embed = new MessageEmbed()
      .setTitle(`${commandName === 'chef-stats' ? 'Chef' : 'Customer'} Stats: ${target.username}`)
      .addField("Points", (user?.points || 0).toString(), true)
      .addField("Orders Completed", (user?.ordersCompleted || 0).toString(), true)
      .setColor(0x0099FF);
      
    await interaction.reply({ embeds: [embed] });
  } 
  
  else if (commandName === 'adjust-points') {
    if (!interaction.member.roles.cache.has(ADMIN_ROLE_ID)) {
      return interaction.reply({ content: "Admins only.", ephemeral: true });
    }
    
    const target = options.getUser('user');
    const points = options.getInteger('points');
    const reason = options.getString('reason') || "No reason provided";
    
    let user = await storage.getUserByDiscordId(target.id);
    if (!user) {
      user = await storage.createUser({ discordId: target.id, username: target.username, role: "customer" });
    }
    
    await storage.setUserPoints(target.id, points);
    
    await interaction.reply({ 
      content: `Set points for ${target} to ${points}. Reason: ${reason}`,
      ephemeral: true 
    });
  }

  else if (commandName === 'lbreset') {
    if (!interaction.member.roles.cache.has(ADMIN_ROLE_ID)) {
      return interaction.reply({ content: "Admins only.", ephemeral: true });
    }
    
    await storage.resetLeaderboards();
    
    await interaction.reply({ 
      content: "Leaderboards have been reset! All points and order counts set to 0.",
      ephemeral: true 
    });
  }

  else if (commandName === 'discount') {
    if (!interaction.member.roles.cache.has(CHEF_ROLE_ID)) {
      return interaction.reply({ content: "Chefs only.", ephemeral: true });
    }
    
    const orderId = options.getString('order_id');
    const discountInput = options.getString('discount');
    const customer = options.getUser('customer');
    const description = options.getString('description');
    
    // Get the order to find the total bill
    const order = await storage.getOrder(orderId);
    if (!order) {
      return interaction.reply({ content: `Order ${orderId} not found.`, ephemeral: true });
    }
    
    // Parse total bill from order details
    const totalMatch = order.details?.match(/(?:total|bill|price)[:\s]*\$?([\d,.]+)/i);
    let originalTotal = 0;
    if (totalMatch) {
      originalTotal = parseFloat(totalMatch[1].replace(/,/g, ''));
    }
    
    if (originalTotal <= 0) {
      return interaction.reply({ content: "Could not find the original total bill in the order.", ephemeral: true });
    }
    
    // Parse discount - can be "25%" or "25"
    let discountValue = 0;
    const percentMatch = discountInput.match(/^(\d+(?:\.\d+)?)\s*%?$/);
    if (percentMatch) {
      discountValue = parseFloat(percentMatch[1]);
    }
    
    if (discountValue <= 0) {
      return interaction.reply({ content: "Invalid discount value.", ephemeral: true });
    }
    
    // Calculate discounted total (subtract percentage)
    const discountAmount = originalTotal * (discountValue / 100);
    const discountedTotal = originalTotal - discountAmount;
    
    // Send the discount message in the format requested
    const discountChannel = interaction.guild.channels.cache.get(DISCOUNT_CHANNEL_ID);
    if (discountChannel?.isText()) {
      // Text message format
      const textMessage = `⸝⸝ *discounted !* ${customer}\n${description}`;
      
      // Embed with receipt format
      const embed = new MessageEmbed()
        .setDescription(`Applied ${discountValue}% discount to Order ${orderId}.\nOriginal: **$${originalTotal.toFixed(0)}**\nNew total: **$${discountedTotal.toFixed(0)}**`)
        .setColor(0xFF00FF)
        .addField("Original Total Bill", `$${originalTotal.toFixed(0)}`, true)
        .addField("Discounted Total Bill", `$${discountedTotal.toFixed(0)}`, true);
        
      await discountChannel.send({ content: textMessage, embeds: [embed] });
      await interaction.reply({ content: "Discount applied and logged.", ephemeral: true });
    } else {
      // If no discount channel, reply in current channel
      const textMessage = `⸝⸝ *discounted !* ${customer}\n${description}`;
      
      const embed = new MessageEmbed()
        .setDescription(`Applied ${discountValue}% discount to Order ${orderId}.\nOriginal: **$${originalTotal.toFixed(0)}**\nNew total: **$${discountedTotal.toFixed(0)}**`)
        .setColor(0xFF00FF)
        .addField("Original Total Bill", `$${originalTotal.toFixed(0)}`, true)
        .addField("Discounted Total Bill", `$${discountedTotal.toFixed(0)}`, true);
        
      await interaction.reply({ content: textMessage, embeds: [embed] });
    }
  }
}
