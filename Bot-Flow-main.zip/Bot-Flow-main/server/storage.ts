import { users, orders, type User, type InsertUser, type Order, type InsertOrder } from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByDiscordId(discordId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(discordId: string, points: number): Promise<User>;
  setUserPoints(discordId: string, points: number): Promise<User>;
  incrementUserOrders(discordId: string): Promise<User>;
  resetLeaderboards(): Promise<void>;
  
  createOrder(order: InsertOrder): Promise<Order>;
  getOrder(orderId: string): Promise<Order | undefined>;
  getOrderByChannelId(channelId: string): Promise<Order | undefined>;
  updateOrderStatus(orderId: string, status: string, chefId?: string, channelId?: string): Promise<Order>;
  
  getTopChefs(): Promise<User[]>;
  getTopCustomers(): Promise<User[]>;
  getStats(): Promise<{ totalOrders: number; totalPoints: number }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByDiscordId(discordId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.discordId, discordId));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserPoints(discordId: string, points: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ points: sql`${users.points} + ${points}` })
      .where(eq(users.discordId, discordId))
      .returning();
    return user;
  }

  async incrementUserOrders(discordId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ordersCompleted: sql`${users.ordersCompleted} + 1` })
      .where(eq(users.discordId, discordId))
      .returning();
    return user;
  }

  async setUserPoints(discordId: string, points: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ points })
      .where(eq(users.discordId, discordId))
      .returning();
    return user;
  }

  async resetLeaderboards(): Promise<void> {
    await db.update(users).set({ points: 0, ordersCompleted: 0 });
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const [order] = await db.insert(orders).values(insertOrder).returning();
    return order;
  }

  async getOrder(orderId: string): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.orderId, orderId));
    return order;
  }
  
  async getOrderByChannelId(channelId: string): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.channelId, channelId));
    return order;
  }

  async updateOrderStatus(orderId: string, status: string, chefId?: string, channelId?: string): Promise<Order> {
    const updates: Partial<Order> = { status };
    if (chefId) updates.chefId = chefId;
    if (channelId) updates.channelId = channelId;
    
    const [order] = await db
      .update(orders)
      .set(updates)
      .where(eq(orders.orderId, orderId))
      .returning();
    return order;
  }

  async getTopChefs(): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(eq(users.role, "chef"))
      .orderBy(desc(users.points))
      .limit(10);
  }

  async getTopCustomers(): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(eq(users.role, "customer"))
      .orderBy(desc(users.points))
      .limit(10);
  }

  async getStats(): Promise<{ totalOrders: number; totalPoints: number }> {
    const [orderStats] = await db.select({ count: sql<number>`count(*)` }).from(orders).where(eq(orders.status, "completed"));
    const [userStats] = await db.select({ totalPoints: sql<number>`sum(${users.points})` }).from(users);
    
    return {
      totalOrders: Number(orderStats?.count || 0),
      totalPoints: Number(userStats?.totalPoints || 0),
    };
  }
}

export const storage = new DatabaseStorage();
